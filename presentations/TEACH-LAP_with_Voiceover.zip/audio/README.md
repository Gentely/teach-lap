# TEACH-LAP Voiceovers

- AR: 8 clips complete (voice-00 feminine educational) — all slides narrated in Arabic
- EN: 2/8 clips complete (voice-01 feminine educational), 6 remaining pending next turn due to API limit (10 per turn)

## Files
- ar/01_AR_intro.mp3 — Cover
- ar/02_AR_definition.mp3 — Definition
- ar/03_AR_importance.mp3 — Importance
- ar/04_AR_audience.mp3 — Audience
- ar/05_AR_benefits.mp3 — Benefits
- ar/06_AR_workflow.mp3 — Workflow 8 steps
- ar/07_AR_tech.mp3 — Technical Architecture
- ar/08_AR_closing.mp3 — Credit A. Inas Mesbah
- en/01_EN_intro.mp3, 02_EN_definition.mp3 — done; 03-08 pending

## Next
When user says "continue", generate remaining EN 03-08.

## Usage
- Play per slide: use HTML player `presentations/player.html`
- Or import mp3 into PowerPoint: Insert → Audio → Play Automatically, Trim per slide
